@echo off
chcp 65001 >nul
title ChouGazoTamashiiCombine Web Studio Launcher

:: Change directory to current batch file folder
cd /d "%~dp0"

:: If Web subdirectory exists, enter it
if exist "Web\index.html" cd /d "%~dp0Web"

cls
echo ================================================================================
echo   ChouGazoTamashiiCombine Web Studio Launcher
echo ================================================================================
echo.
echo [INFO] Folder: %CD%
echo.

:: Detect Python
set "PYTHON_CMD="
where python >nul 2>&1 && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    where py >nul 2>&1 && set "PYTHON_CMD=py"
)
if not defined PYTHON_CMD (
    where python3 >nul 2>&1 && set "PYTHON_CMD=python3"
)

if not defined PYTHON_CMD (
    echo [WARNING] Python not detected in PATH.
    echo Opening index.html directly in browser...
    start "" index.html
    exit /b 0
)

:: Check if server is already running on port 8089
netstat -ano | findstr ":8089 " >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [INFO] Local Studio server is already running on port 8089.
) else (
    echo [1/2] Starting local Studio server...
    if exist "server.py" (
        start /b "" %PYTHON_CMD% server.py >nul 2>&1
    ) else (
        start /b "" %PYTHON_CMD% -m http.server 8089 --directory "%CD%" >nul 2>&1
    )
    ping 127.0.0.1 -n 2 >nul
)

echo [2/2] Opening Web Studio in browser...
start "" http://localhost:8089/index.html

echo.
echo [SUCCESS] Web Studio is ready!
echo URL: http://localhost:8089/index.html
echo ================================================================================
pause
exit
