# -*- coding: utf-8 -*-
"""
✨ 超画像魂コンバイン Web Studio - Local Server & INI Manager
🤖 Generated & Engineered with: Google Gemini
💎 Features: 静的ファイル配信 ✕ settings.ini 自動生成/同期 ✕ フォルダパス永続化 ✕ ローカル直接保存
"""

import os
import sys
import json
import configparser
from http.server import HTTPServer, SimpleHTTPRequestHandler
import urllib.parse

PORT = 8089
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INI_PATH = os.path.join(BASE_DIR, "settings.ini")

def load_or_create_ini():
    config = configparser.ConfigParser()
    if not os.path.exists(INI_PATH):
        config["Settings"] = {
            "LastFolderPath": BASE_DIR,
            "TileWidth": "48",
            "TileHeight": "48",
            "CanvasCols": "16",
            "CanvasRows": "12",
            "PaletteMode": "sheet",
            "PaletteScale": "1.0",
            "CanvasBgColor": "transparent"
        }
        with open(INI_PATH, "w", encoding="utf-8") as f:
            config.write(f)
        print(f"[INI] Created default settings.ini at: {INI_PATH}")
    else:
        try:
            config.read(INI_PATH, encoding="utf-8")
        except Exception as e:
            print(f"[INI Warning] Failed to read with utf-8, trying cp932: {e}")
            config.read(INI_PATH, encoding="cp932")
    return config

def save_ini(data):
    config = configparser.ConfigParser()
    config["Settings"] = {
        "LastFolderPath": str(data.get("lastFolderPath", BASE_DIR)),
        "TileWidth": str(data.get("tileWidth", 48)),
        "TileHeight": str(data.get("tileHeight", 48)),
        "CanvasCols": str(data.get("canvasCols", 16)),
        "CanvasRows": str(data.get("canvasRows", 12)),
        "PaletteMode": str(data.get("paletteMode", "sheet")),
        "PaletteScale": str(data.get("paletteScale", "1.0")),
        "CanvasBgColor": str(data.get("canvasBgColor", "transparent"))
    }
    with open(INI_PATH, "w", encoding="utf-8") as f:
        config.write(f)
    print(f"[INI] Saved settings.ini successfully.")

class StudioHTTPHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/settings":
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            cfg = load_or_create_ini()
            resp = {
                "baseDir": BASE_DIR,
                "lastFolderPath": cfg.get("Settings", "LastFolderPath", fallback=BASE_DIR),
                "tileWidth": int(cfg.get("Settings", "TileWidth", fallback=48)),
                "tileHeight": int(cfg.get("Settings", "TileHeight", fallback=48)),
                "canvasCols": int(cfg.get("Settings", "CanvasCols", fallback=16)),
                "canvasRows": int(cfg.get("Settings", "CanvasRows", fallback=12)),
                "paletteMode": cfg.get("Settings", "PaletteMode", fallback="sheet"),
                "paletteScale": float(cfg.get("Settings", "PaletteScale", fallback=1.0)),
                "canvasBgColor": cfg.get("Settings", "CanvasBgColor", fallback="transparent")
            }
            self.wfile.write(json.dumps(resp, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/files":
            qs = urllib.parse.parse_qs(parsed.query)
            target_dir = qs.get("dir", [None])[0]
            if not target_dir or not os.path.exists(target_dir):
                cfg = load_or_create_ini()
                target_dir = cfg.get("Settings", "LastFolderPath", fallback=BASE_DIR)

            files_list = []
            if os.path.exists(target_dir):
                for fname in os.listdir(target_dir):
                    fpath = os.path.join(target_dir, fname)
                    if os.path.isfile(fpath):
                        ext = os.path.splitext(fname)[1].lower()
                        if ext in [".png", ".jpg", ".jpeg", ".webp", ".tilemap", ".json", ".xml"]:
                            files_list.append({
                                "name": fname,
                                "path": fpath,
                                "ext": ext,
                                "size": os.path.getsize(fpath)
                            })
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps({"currentDir": target_dir, "files": files_list}, ensure_ascii=False).encode("utf-8"))
            return

        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/settings":
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode("utf-8"))
                save_ini(data)
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode("utf-8"))
            return

        elif path == "/api/save_project":
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)
            try:
                payload = json.loads(body.decode("utf-8"))
                cfg = load_or_create_ini()
                save_dir = payload.get("dir") or cfg.get("Settings", "LastFolderPath", fallback=BASE_DIR)
                filename = payload.get("filename", "project.tilemap")
                if not os.path.exists(save_dir):
                    save_dir = BASE_DIR
                
                full_path = os.path.join(save_dir, filename)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(payload.get("content", ""))
                
                cfg.set("Settings", "LastFolderPath", save_dir)
                with open(INI_PATH, "w", encoding="utf-8") as f:
                    cfg.write(f)

                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "path": full_path}).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode("utf-8"))
            return

        return super().do_POST()

def main():
    os.chdir(BASE_DIR)
    load_or_create_ini()
    server_address = ("", PORT)
    httpd = HTTPServer(server_address, StudioHTTPHandler)
    print("=" * 70)
    print(f"[SERVER] ChouGazoTamashiiCombine Web Studio Server running on port {PORT}")
    print(f"[DIR] Base Directory: {BASE_DIR}")
    print(f"[INI] INI File: {INI_PATH}")
    print("=" * 70)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        httpd.server_close()

if __name__ == "__main__":
    main()

