/**
 * ✨ 超画像魂コンバイン Web Studio - Core Engine (app.js)
 * 
 * 🤖 Generated & Engineered with: Google Gemini
 * 🚀 Web Modernization: Google Gemini (HTML5 Canvas / Vanilla ES6+ / Dark Glassmorphism)
 * 💎 Features: パズルピース型画像結合 ✕ タイル自動整列 ✕ 一括透明化 ✕ 現代フォーマット出力 ✕ *.tilemap互換
 */

(() => {
  'use strict';

  // =========================================================================
  // 1. アプリケーション・グローバルステート
  // =========================================================================
  const state = {
    tileWidth: 32,
    tileHeight: 32,
    canvasCols: 16,
    canvasRows: 16,
    zoom: 1.0,
    minZoom: 0.25,
    maxZoom: 6.0,

    pieces: [],          // スライスされたピース配列 [{ id, canvas, name }]
    selectedPieceId: null, // パレットで選択中のピースID
    selectedCell: null,    // キャンバス上で選択中のセル { col, row }

    // キャンバス上のセルデータ: Map("col_row" => { pieceId, rotation, flipH, flipV })
    gridMap: new Map(),

    // 履歴管理 (Undo / Redo)
    undoStack: [],
    redoStack: [],
    maxHistory: 30,

    // 表示設定
    showGrid: true,
    showChecker: true,

    // スポイトモード
    eyedropperActive: false,
    chromaColor: { r: 0, g: 0, b: 0 },
    chromaTolerance: 15,

    // パレット新機能: つなげて表示 ＆ ワイド展開 ＆ ズーム
    paletteMode: 'sheet', // 'sheet' (つなげて表示) または 'grid' (一覧表示)
    paletteScale: 1.0,    // 1.0 (32px), 1.5 (48px), 2.0 (64px)
    paletteWide: false,   // true でサイドバー横幅拡大
    sourceCols: 16,       // 元画像の列数 (シート配置用)
    lastLoadedImage: null, // { img, name } 最後に読み込んだ画像（動的再スライス用）
    isDraggingInternalPiece: false, // 内部ピースドラッグ中に外部ファイルドロップと誤認されるのを完全防止
    baseDir: '',           // index.html のあるディレクトリ
    lastFolderPath: '',    // settings.ini に永続化されるデフォルトフォルダパス
    canvasBgColor: 'transparent' // キャンバス背景色 ('transparent' または hexカラー)
  };

  // =========================================================================
  // 2. DOM要素の取得
  // =========================================================================
  const DOM = {
    mainWorkspace: document.querySelector('.main-workspace'),

    // ツールバー
    btnImport: document.getElementById('btn-import-image'),
    fileInput: document.getElementById('file-input-image'),
    btnOpenProject: document.getElementById('btn-open-project'),
    fileInputProject: document.getElementById('file-input-project'),
    btnSaveProject: document.getElementById('btn-save-project'),
    btnLoadSample: document.getElementById('btn-load-sample'),
    btnUndo: document.getElementById('btn-undo'),
    btnRedo: document.getElementById('btn-redo'),
    btnClear: document.getElementById('btn-clear-canvas'),
    btnZoomIn: document.getElementById('btn-zoom-in'),
    btnZoomOut: document.getElementById('btn-zoom-out'),
    btnZoomReset: document.getElementById('btn-zoom-reset'),
    zoomLabel: document.getElementById('zoom-level-label'),
    btnOpenExport: document.getElementById('btn-open-export-modal'),

    // 背景色設定コントロール
    btnCanvasBg: document.getElementById('btn-canvas-bg'),
    bgColorPreview: document.getElementById('bg-color-preview'),
    bgPalettePopover: document.getElementById('bg-palette-popover'),
    btnCloseBgPalette: document.getElementById('btn-close-bg-palette'),
    bgPresetBtns: document.querySelectorAll('.bg-preset-btn'),
    customBgColorPicker: document.getElementById('custom-bg-color-picker'),
    customBgColorHex: document.getElementById('custom-bg-color-hex'),
    btnApplyCustomBg: document.getElementById('btn-apply-custom-bg'),

    // 左サイドバー (パレット)
    btnTogglePaletteWide: document.getElementById('btn-toggle-palette-wide'),
    btnModeSheet: document.getElementById('btn-mode-sheet'),
    btnModeGrid: document.getElementById('btn-mode-grid'),
    paletteScaleBtns: document.querySelectorAll('.palette-scale-btn'),
    paletteGrid: document.getElementById('palette-grid'),
    paletteEmptyMsg: document.getElementById('palette-empty-msg'),
    pieceCountBadge: document.getElementById('piece-count-badge'),
    sizeChips: document.querySelectorAll('.size-chip'),
    inputCustomW: document.getElementById('custom-tile-w'),
    inputCustomH: document.getElementById('custom-tile-h'),
    btnApplyCustomSize: document.getElementById('btn-apply-custom-size'),
    btnSelectAll: document.getElementById('btn-select-all-pieces'),
    btnDeselect: document.getElementById('btn-deselect-pieces'),

    // キャンバス
    scrollContainer: document.getElementById('canvas-scroll-container'),
    transformWrapper: document.getElementById('canvas-transform-wrapper'),
    mainCanvas: document.getElementById('main-combine-canvas'),
    checkerCanvas: document.getElementById('checker-canvas'),
    gridOverlay: document.getElementById('grid-overlay'),
    chkShowGrid: document.getElementById('chk-show-grid'),
    chkShowChecker: document.getElementById('chk-show-checker'),
    statusText: document.getElementById('canvas-status-text'),
    specText: document.getElementById('canvas-grid-spec'),

    // 右サイドバー (新機能ツール)
    inputAlignCols: document.getElementById('align-columns'),
    btnAlignOriginal: document.getElementById('btn-auto-align-original'),
    btnAlignGrid: document.getElementById('btn-auto-align-grid'),
    btnAlignSquare: document.getElementById('btn-auto-align-square'),

    btnEyedropper: document.getElementById('btn-eyedropper'),
    colorPicker: document.getElementById('chroma-target-color'),
    colorHexText: document.getElementById('chroma-color-hex'),
    sliderTolerance: document.getElementById('chroma-tolerance'),
    toleranceVal: document.getElementById('tolerance-val'),
    colorPresets: document.querySelectorAll('.color-preset-chip'),
    btnApplyChroma: document.getElementById('btn-apply-transparency'),

    btnRotateCW: document.getElementById('btn-rotate-cw'),
    btnFlipH: document.getElementById('btn-flip-h'),
    btnFlipV: document.getElementById('btn-flip-v'),
    btnRemoveSelected: document.getElementById('btn-remove-selected'),

    inputCanvasCols: document.getElementById('canvas-cols'),
    inputCanvasRows: document.getElementById('canvas-rows'),
    btnResizeCanvas: document.getElementById('btn-resize-canvas'),

    // モーダル
    modalExport: document.getElementById('modal-export'),
    btnCloseModal: document.getElementById('btn-close-export-modal'),
    previewCanvas: document.getElementById('export-preview-canvas'),
    exportInfoText: document.getElementById('export-info-text'),
    exportFilename: document.getElementById('export-filename'),
    exportFmtRadios: document.getElementsByName('export-fmt'),
    webpGroup: document.getElementById('webp-quality-group'),
    webpSlider: document.getElementById('webp-quality'),
    webpQualityVal: document.getElementById('webp-quality-val'),
    btnConfirmExport: document.getElementById('btn-confirm-export'),
    btnExportZip: document.getElementById('btn-export-zip'),

    toastContainer: document.getElementById('toast-container')
  };

  // 描画コンテキスト
  const mainCtx = DOM.mainCanvas.getContext('2d');
  const checkerCtx = DOM.checkerCanvas.getContext('2d');
  const previewCtx = DOM.previewCanvas.getContext('2d');

  // =========================================================================
  // 3. 初期化とイベントバインド
  // =========================================================================
  function init() {
    updateCanvasDimensions();
    bindEvents();
    renderAll();
    loadIniSettings();
    showToast('超画像魂コンバイン Web Studio 起動完了！', '✨');
  }

  async function loadIniSettings() {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const cfg = await res.json();
        state.baseDir = cfg.baseDir || '';
        state.lastFolderPath = cfg.lastFolderPath || cfg.baseDir || '';
        if (cfg.tileWidth && cfg.tileHeight) {
          state.tileWidth = cfg.tileWidth;
          state.tileHeight = cfg.tileHeight;
          DOM.inputCustomW.value = state.tileWidth;
          DOM.inputCustomH.value = state.tileHeight;
          DOM.sizeChips.forEach(c => {
            const s = parseInt(c.dataset.size, 10);
            c.classList.toggle('active', s === state.tileWidth && state.tileWidth === state.tileHeight);
          });
        }
        if (cfg.paletteMode) {
          setPaletteMode(cfg.paletteMode);
        }
        if (cfg.paletteScale) {
          setPaletteScale(cfg.paletteScale);
        }
        if (cfg.canvasBgColor) {
          setCanvasBgColor(cfg.canvasBgColor, true);
        }
        updateCanvasDimensions();
        renderAll();
        console.log('[INI] Loaded settings.ini:', cfg);
      }
    } catch (e) {
      console.log('[INI] Standalone mode (settings.ini offline)');
    }
  }

  async function saveIniSettings() {
    try {
      const payload = {
        lastFolderPath: state.lastFolderPath || state.baseDir,
        tileWidth: state.tileWidth,
        tileHeight: state.tileHeight,
        canvasCols: state.canvasCols,
        canvasRows: state.canvasRows,
        paletteMode: state.paletteMode,
        paletteScale: state.paletteScale,
        canvasBgColor: state.canvasBgColor || 'transparent'
      };
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      console.log('[INI] Saved settings.ini successfully');
    } catch (e) {
      // Standalone mode
    }
  }

  function bindEvents() {
    // ファイル読み込み (安全・確実なブラウザファイルピッカー)
    DOM.btnImport.addEventListener('click', () => DOM.fileInput.click());
    DOM.fileInput.addEventListener('change', handleFileSelect);
    DOM.btnOpenProject.addEventListener('click', () => DOM.fileInputProject.click());
    DOM.fileInputProject.addEventListener('change', handleProjectFileSelect);
    DOM.btnSaveProject.addEventListener('click', saveProject);
    DOM.btnLoadSample.addEventListener('click', loadSampleDungeon);

    // ドラッグ＆ドロップ (ウィンドウ全体)
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', handleWindowDrop);

    // タイルサイズ変更チップ
    DOM.sizeChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const s = parseInt(chip.dataset.size, 10);
        setTileSize(s, s, true);
      });
    });

    DOM.btnApplyCustomSize.addEventListener('click', () => {
      const w = Math.max(4, parseInt(DOM.inputCustomW.value, 10) || 32);
      const h = Math.max(4, parseInt(DOM.inputCustomH.value, 10) || 32);
      setTileSize(w, h, true);
    });

    // ズーム
    DOM.btnZoomIn.addEventListener('click', () => setZoom(state.zoom * 1.25));
    DOM.btnZoomOut.addEventListener('click', () => setZoom(state.zoom / 1.25));
    DOM.btnZoomReset.addEventListener('click', resetZoom);
    DOM.scrollContainer.addEventListener('wheel', handleCanvasWheel, { passive: false });

    // 履歴操作
    DOM.btnUndo.addEventListener('click', undo);
    DOM.btnRedo.addEventListener('click', redo);
    DOM.btnClear.addEventListener('click', clearCanvas);

    // グリッド線・透過チェッカー切り替え
    DOM.chkShowGrid.addEventListener('change', (e) => {
      state.showGrid = e.target.checked;
      DOM.gridOverlay.style.display = state.showGrid ? 'block' : 'none';
    });
    DOM.chkShowChecker.addEventListener('change', (e) => {
      state.showChecker = e.target.checked;
      DOM.checkerCanvas.style.display = state.showChecker ? 'block' : 'none';
    });

    // キャンバスリサイズ
    DOM.btnResizeCanvas.addEventListener('click', () => {
      const c = Math.max(1, parseInt(DOM.inputCanvasCols.value, 10) || 16);
      const r = Math.max(1, parseInt(DOM.inputCanvasRows.value, 10) || 16);
      pushHistory();
      state.canvasCols = c;
      state.canvasRows = r;
      updateCanvasDimensions();
      renderAll();
      showToast(`キャンバスを ${c}x${r} タイルに変更しました`);
    });

    // キャンバスインタラクション (クリック、ドラッグ＆ドロップ)
    DOM.gridOverlay.addEventListener('click', handleCanvasClick);
    DOM.gridOverlay.addEventListener('dragover', handleCanvasDragOver);
    DOM.gridOverlay.addEventListener('drop', handleCanvasDrop);

    // 新機能 ①: 自動整列
    if (DOM.btnAlignOriginal) {
      DOM.btnAlignOriginal.addEventListener('click', autoAlignOriginal);
    }
    DOM.btnAlignGrid.addEventListener('click', () => {
      const cols = Math.max(1, parseInt(DOM.inputAlignCols.value, 10) || 8);
      autoAlignPieces(cols);
    });
    DOM.btnAlignSquare.addEventListener('click', () => {
      autoAlignSquare();
    });

    // 新機能 ②: 透明色一括抜き
    DOM.btnEyedropper.addEventListener('click', toggleEyedropper);
    DOM.colorPicker.addEventListener('input', (e) => {
      updateChromaColor(e.target.value);
    });
    DOM.sliderTolerance.addEventListener('input', (e) => {
      state.chromaTolerance = parseInt(e.target.value, 10);
      DOM.toleranceVal.textContent = state.chromaTolerance;
    });
    DOM.colorPresets.forEach(chip => {
      chip.addEventListener('click', () => {
        updateChromaColor(chip.dataset.color);
      });
    });
    DOM.btnApplyChroma.addEventListener('click', applyTransparencyToAll);

    // 変形操作
    DOM.btnRotateCW.addEventListener('click', rotateSelectedCell);
    DOM.btnFlipH.addEventListener('click', flipHSelectedCell);
    DOM.btnFlipV.addEventListener('click', flipVSelectedCell);
    DOM.btnRemoveSelected.addEventListener('click', removeSelectedCell);

    // パレット選択操作
    DOM.btnSelectAll.addEventListener('click', selectAllPieces);
    DOM.btnDeselect.addEventListener('click', deselectPieces);

    // パレット表示モード ＆ ズーム ＆ ワイド表示
    if (DOM.btnTogglePaletteWide) {
      DOM.btnTogglePaletteWide.addEventListener('click', togglePaletteWide);
    }
    if (DOM.btnModeSheet) {
      DOM.btnModeSheet.addEventListener('click', () => setPaletteMode('sheet'));
    }
    if (DOM.btnModeGrid) {
      DOM.btnModeGrid.addEventListener('click', () => setPaletteMode('grid'));
    }
    if (DOM.paletteScaleBtns) {
      DOM.paletteScaleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          const s = parseFloat(btn.dataset.scale);
          setPaletteScale(s);
        });
      });
    }

    // エクスポートモーダル
    DOM.btnOpenExport.addEventListener('click', openExportModal);
    DOM.btnCloseModal.addEventListener('click', closeExportModal);
    DOM.modalExport.addEventListener('click', (e) => {
      if (e.target === DOM.modalExport) closeExportModal();
    });
    Array.from(DOM.exportFmtRadios).forEach(radio => {
      radio.addEventListener('change', () => {
        DOM.webpGroup.style.display = (radio.value === 'webp' && radio.checked) ? 'flex' : 'none';
      });
    });
    DOM.webpSlider.addEventListener('input', (e) => {
      DOM.webpQualityVal.textContent = `${e.target.value}%`;
    });
    DOM.btnConfirmExport.addEventListener('click', executeExportImage);
    DOM.btnExportZip.addEventListener('click', executeExportZip);

    // 背景色設定コントロール
    if (DOM.btnCanvasBg && DOM.bgPalettePopover) {
      DOM.btnCanvasBg.addEventListener('click', (e) => {
        e.stopPropagation();
        DOM.bgPalettePopover.classList.toggle('hidden');
      });
      if (DOM.btnCloseBgPalette) {
        DOM.btnCloseBgPalette.addEventListener('click', (e) => {
          e.stopPropagation();
          DOM.bgPalettePopover.classList.add('hidden');
        });
      }
      DOM.bgPalettePopover.addEventListener('click', (e) => {
        e.stopPropagation();
      });
      document.addEventListener('click', (e) => {
        if (!DOM.bgPalettePopover.classList.contains('hidden') && !DOM.bgPalettePopover.contains(e.target) && e.target !== DOM.btnCanvasBg) {
          DOM.bgPalettePopover.classList.add('hidden');
        }
      });
    }

    if (DOM.bgPresetBtns) {
      DOM.bgPresetBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          const color = btn.dataset.color;
          setCanvasBgColor(color);
        });
      });
    }

    if (DOM.customBgColorPicker && DOM.customBgColorHex) {
      DOM.customBgColorPicker.addEventListener('input', (e) => {
        DOM.customBgColorHex.value = e.target.value.toUpperCase();
      });
      DOM.customBgColorHex.addEventListener('input', (e) => {
        const val = e.target.value.trim();
        if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
          DOM.customBgColorPicker.value = val;
        }
      });
    }

    if (DOM.btnApplyCustomBg) {
      DOM.btnApplyCustomBg.addEventListener('click', () => {
        const val = DOM.customBgColorHex.value.trim();
        if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
          setCanvasBgColor(val);
        } else {
          showToast('カラーコードが正しくありません (例: #FFFFFF)', '⚠️');
        }
      });
    }

    // キーボードショートカット
    window.addEventListener('keydown', handleKeyShortcuts);
  }

  // =========================================================================
  // 4. キャンバス寸法＆チェッカー背景の更新
  // =========================================================================
  function updateCanvasDimensions() {
    const totalW = state.canvasCols * state.tileWidth;
    const totalH = state.canvasRows * state.tileHeight;

    DOM.mainCanvas.width = totalW;
    DOM.mainCanvas.height = totalH;
    DOM.checkerCanvas.width = totalW;
    DOM.checkerCanvas.height = totalH;

    DOM.transformWrapper.style.width = `${totalW}px`;
    DOM.transformWrapper.style.height = `${totalH}px`;

    // 元祖「超画像魂コンバイン」の象徴: 青と白の点々グリッド線の生成
    updateGridPattern();

    // スペック表示
    DOM.specText.textContent = `キャンバス: ${totalW} x ${totalH} px (${state.canvasCols} x ${state.canvasRows} タイル)`;
    DOM.inputCanvasCols.value = state.canvasCols;
    DOM.inputCanvasRows.value = state.canvasRows;

    drawCheckerBackground();
  }

  function updateGridPattern() {
    const w = state.tileWidth;
    const h = state.tileHeight;
    // 元祖「超画像魂コンバイン」象徴の青と白の点々グリッド線 (3px青 / 3px白 の交互ドット)
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
      <defs>
        <pattern id="dot-v" width="1" height="6" patternUnits="userSpaceOnUse">
          <rect width="1" height="3" fill="#0078d7"/>
          <rect y="3" width="1" height="3" fill="#ffffff"/>
        </pattern>
        <pattern id="dot-h" width="6" height="1" patternUnits="userSpaceOnUse">
          <rect width="3" height="1" fill="#0078d7"/>
          <rect x="3" width="3" height="1" fill="#ffffff"/>
        </pattern>
      </defs>
      <line x1="0" y1="0" x2="0" y2="${h}" stroke="url(#dot-v)" stroke-width="1"/>
      <line x1="0" y1="0" x2="${w}" y2="0" stroke="url(#dot-h)" stroke-width="1"/>
    </svg>`;
    DOM.gridOverlay.style.backgroundImage = `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
    DOM.gridOverlay.style.backgroundSize = `${w}px ${h}px`;
  }

  function drawCheckerBackground() {
    const w = DOM.checkerCanvas.width;
    const h = DOM.checkerCanvas.height;
    checkerCtx.clearRect(0, 0, w, h);

    // 背景色が設定されている場合 (透過以外)
    if (state.canvasBgColor && state.canvasBgColor !== 'transparent') {
      checkerCtx.fillStyle = state.canvasBgColor;
      checkerCtx.fillRect(0, 0, w, h);
      return;
    }

    // 透過時はチェッカー模様 (市松模様) を描画
    const size = 16;
    for (let y = 0; y < h; y += size) {
      for (let x = 0; x < w; x += size) {
        checkerCtx.fillStyle = ((x / size + y / size) % 2 === 0) ? '#181b28' : '#10131e';
        checkerCtx.fillRect(x, y, size, size);
      }
    }
  }

  function setCanvasBgColor(color, silent = false) {
    state.canvasBgColor = color || 'transparent';

    // ツールバーボタンのスウォッチ更新
    if (DOM.bgColorPreview) {
      if (state.canvasBgColor === 'transparent') {
        DOM.bgColorPreview.classList.add('is-transparent');
        DOM.bgColorPreview.style.backgroundColor = '';
      } else {
        DOM.bgColorPreview.classList.remove('is-transparent');
        DOM.bgColorPreview.style.backgroundColor = state.canvasBgColor;
      }
    }

    // プリセットボタンのアクティブ更新
    if (DOM.bgPresetBtns) {
      DOM.bgPresetBtns.forEach(btn => {
        const isAct = btn.dataset.color.toLowerCase() === state.canvasBgColor.toLowerCase();
        btn.classList.toggle('active', isAct);
      });
    }

    // カスタム入力欄の同期
    if (state.canvasBgColor !== 'transparent') {
      if (DOM.customBgColorPicker) DOM.customBgColorPicker.value = state.canvasBgColor;
      if (DOM.customBgColorHex) DOM.customBgColorHex.value = state.canvasBgColor.toUpperCase();
    }

    drawCheckerBackground();
    saveIniSettings();

    if (!silent) {
      const label = state.canvasBgColor === 'transparent' ? '透過（市松模様）' : state.canvasBgColor;
      showToast(`背景色を ${label} に変更しました`, '🎨');
    }
  }

  function setZoom(newZoom) {
    state.zoom = Math.min(state.maxZoom, Math.max(state.minZoom, newZoom));
    DOM.transformWrapper.style.transform = `scale(${state.zoom})`;
    DOM.zoomLabel.textContent = `${Math.round(state.zoom * 100)}%`;
  }

  function resetZoom() {
    setZoom(1.0);
    if (DOM.scrollContainer) {
      DOM.scrollContainer.scrollLeft = (DOM.scrollContainer.scrollWidth - DOM.scrollContainer.clientWidth) / 2;
      DOM.scrollContainer.scrollTop = (DOM.scrollContainer.scrollHeight - DOM.scrollContainer.clientHeight) / 2;
    }
    showToast('表示倍率を原寸 (100%) にリセットしました', '🔍');
  }

  function handleCanvasWheel(e) {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY < 0 ? 1.15 : 0.85;
      setZoom(state.zoom * delta);
    }
  }

  // =========================================================================
  // 5. 画像スライサー＆ピース生成
  // =========================================================================
  function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) processImageFile(file);
    e.target.value = '';
  }

  function handleWindowDrop(e) {
    e.preventDefault();

    // 内部ピースのドラッグ中、またはピースIDが含まれている場合は外部ファイル処理を完全無視！
    if (state.isDraggingInternalPiece) return;
    if (e.dataTransfer && e.dataTransfer.types && e.dataTransfer.types.includes('application/x-piece-id')) return;

    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      const lowerName = file.name.toLowerCase();
      if (lowerName.endsWith('.tilemap') || lowerName.endsWith('.json') || lowerName.endsWith('.xml')) {
        loadProjectFile(file);
      } else if (file.type.startsWith('image/')) {
        processImageFile(file);
      }
    }
  }

  function detectOptimalTileSize(img) {
    const w = img.width;
    const h = img.height;
    // 代表的なタイルサイズ (48x48: RPGツクールMV/MZ, 32x32: 2000/XP/VX, 16x16: レトロ, 24x24: ウディタ)
    if (w % 48 === 0 && h % 48 === 0) return 48;
    if (w % 32 === 0 && h % 32 === 0) return 32;
    if (w % 16 === 0 && h % 16 === 0) return 16;
    if (w % 24 === 0 && h % 24 === 0) return 24;
    return state.tileWidth;
  }

  function setTileSize(w, h, autoReslice = true) {
    state.tileWidth = w;
    state.tileHeight = h;
    DOM.inputCustomW.value = w;
    DOM.inputCustomH.value = h;

    // チップのアクティブ状態更新
    DOM.sizeChips.forEach(chip => {
      const s = parseInt(chip.dataset.size, 10);
      chip.classList.toggle('active', s === w && w === h);
    });

    updateCanvasDimensions();
    renderAll();

    // 既に画像が読み込まれていれば、新しいタイルサイズで即座に再スライス！
    if (autoReslice && state.lastLoadedImage) {
      state.pieces = []; // 既存ピースをクリアして再生成
      sliceImageToPieces(state.lastLoadedImage.img, state.lastLoadedImage.name, false);
      showToast(`タイルサイズを ${w}x${h} に変更し、ピースを再生成しました！`, '✨');
    } else {
      updatePaletteView();
      showToast(`タイルサイズを ${w}x${h} に設定しました`);
    }
  }

  function loadSampleDungeon() {
    showToast('サンプル画像を読み込み中...', '⏳');
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // sample_dungeon (768x576) は 48x48 (16x12タイル) が正解！
      setTileSize(48, 48, false);
      state.pieces = [];
      state.lastLoadedImage = { img, name: 'sample_dungeon' };
      sliceImageToPieces(img, 'sample_dungeon', false);
      showToast('サンプルダンジョン (48x48 / 192ピース) を完全整列で読み込みました！', '🎮');
    };
    img.onerror = () => {
      showToast('サンプル画像が見つかりませんでした', '⚠️');
    };
    img.src = 'sample_dungeon.png';
  }

  async function handleImportImageClick() {
    try {
      const res = await fetch('/api/dialog/open_image', { method: 'POST' });
      if (res.ok) {
        const ret = await res.json();
        if (ret.canceled) return;
        if (ret.dataUrl) {
          processImageDataUrl(ret.dataUrl, ret.filename);
          return;
        }
      }
    } catch (e) {
      // サーバー未稼働時はブラウザ標準のダイアログへフォールバック
    }
    DOM.fileInput.click();
  }

  function processImageDataUrl(dataUrl, fileName) {
    const img = new Image();
    img.onload = () => {
      const optSize = detectOptimalTileSize(img);
      if (optSize !== state.tileWidth) {
        setTileSize(optSize, optSize, false);
      }
      state.pieces = [];
      state.lastLoadedImage = { img, name: fileName };
      sliceImageToPieces(img, fileName, false);
      showToast(`${fileName} を読み込みました (検出サイズ: ${optSize}x${optSize})！`, '✨');
    };
    img.src = dataUrl;
  }

  function processImageFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      processImageDataUrl(e.target.result, file.name);
    };
    reader.readAsDataURL(file);
  }

  function sliceImageToPieces(image, sourceName, saveLast = true) {
    if (saveLast) {
      state.lastLoadedImage = { img: image, name: sourceName };
    }

    const tw = state.tileWidth;
    const th = state.tileHeight;
    const cols = Math.floor(image.width / tw);
    const rows = Math.floor(image.height / th);

    if (cols === 0 || rows === 0) {
      showToast('画像がタイルサイズより小さすぎます', '⚠️');
      return;
    }

    // 元画像の列数を記憶（シートモードで元画像通りに並べるため）
    state.sourceCols = cols;

    // 自動整列の入力欄も元画像の列数（例: 16列）に初期同期！
    if (DOM.inputAlignCols) {
      DOM.inputAlignCols.value = cols;
    }

    const startIndex = state.pieces.length;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const offCanvas = document.createElement('canvas');
        offCanvas.width = tw;
        offCanvas.height = th;
        const offCtx = offCanvas.getContext('2d');
        offCtx.imageSmoothingEnabled = false;

        offCtx.drawImage(
          image,
          c * tw, r * th, tw, th,
          0, 0, tw, th
        );

        const pieceId = `p_${startIndex + (r * cols + c)}_${Date.now()}`;
        state.pieces.push({
          id: pieceId,
          canvas: offCanvas,
          name: `${sourceName}_x${c}_y${r}`,
          col: c,
          row: r
        });
      }
    }

    updatePaletteView();
  }

  function updatePaletteView() {
    DOM.paletteGrid.innerHTML = '';

    if (state.pieces.length === 0) {
      DOM.paletteEmptyMsg.style.display = 'block';
      DOM.pieceCountBadge.textContent = '0 ピース';
      return;
    }

    DOM.paletteEmptyMsg.style.display = 'none';
    DOM.pieceCountBadge.textContent = `${state.pieces.length} ピース`;

    // CSS変数で列数と表示サイズを動的設定
    const piecePx = Math.round(state.tileWidth * state.paletteScale);
    DOM.paletteGrid.style.setProperty('--sheet-cols', state.sourceCols || 16);
    DOM.paletteGrid.style.setProperty('--piece-size', `${piecePx}px`);
    DOM.paletteGrid.className = `palette-scroll-area mode-${state.paletteMode}`;

    state.pieces.forEach((piece) => {
      const itemEl = document.createElement('div');
      itemEl.className = 'palette-piece';
      itemEl.dataset.id = piece.id;
      itemEl.draggable = true;
      itemEl.title = `${piece.name} (${state.tileWidth}x${state.tileHeight})`;

      const imgEl = document.createElement('img');
      imgEl.src = piece.canvas.toDataURL();
      imgEl.alt = piece.name;
      imgEl.draggable = false; // img自体のネイティブファイルドラッグ化を完全禁止！
      itemEl.appendChild(imgEl);

      if (state.selectedPieceId === piece.id) {
        itemEl.classList.add('selected');
      }

      // クリックで選択
      itemEl.addEventListener('click', () => {
        DOM.paletteGrid.querySelectorAll('.palette-piece').forEach(p => p.classList.remove('selected'));
        if (state.selectedPieceId === piece.id) {
          state.selectedPieceId = null;
        } else {
          state.selectedPieceId = piece.id;
          itemEl.classList.add('selected');
        }
      });

      // ドラッグ開始
      itemEl.addEventListener('dragstart', (e) => {
        state.isDraggingInternalPiece = true;
        e.dataTransfer.setData('text/plain', piece.id);
        e.dataTransfer.setData('application/x-piece-id', piece.id);
        e.dataTransfer.effectAllowed = 'copyMove';
      });

      // ドラッグ終了
      itemEl.addEventListener('dragend', () => {
        state.isDraggingInternalPiece = false;
      });

      DOM.paletteGrid.appendChild(itemEl);
    });
  }

  function togglePaletteWide() {
    state.paletteWide = !state.paletteWide;
    if (DOM.mainWorkspace) {
      DOM.mainWorkspace.classList.toggle('left-wide', state.paletteWide);
    }
    if (DOM.btnTogglePaletteWide) {
      DOM.btnTogglePaletteWide.classList.toggle('active', state.paletteWide);
      const textSpan = DOM.btnTogglePaletteWide.querySelector('.btn-text');
      if (textSpan) {
        textSpan.textContent = state.paletteWide ? '狭める' : '広げる';
      }
    }
    showToast(state.paletteWide ? 'パレットをワイド表示（600px）に広げました！' : 'パレット幅を通常に戻しました');
  }

  function setPaletteMode(mode) {
    state.paletteMode = mode;
    if (DOM.btnModeSheet) DOM.btnModeSheet.classList.toggle('active', mode === 'sheet');
    if (DOM.btnModeGrid) DOM.btnModeGrid.classList.toggle('active', mode === 'grid');
    updatePaletteView();
    showToast(mode === 'sheet' ? '🗺️ 元画像通りにつなげて表示に切り替えました' : '🧩 一覧グリッド表示に切り替えました');
  }

  function setPaletteScale(scale) {
    state.paletteScale = scale;
    if (DOM.paletteScaleBtns) {
      DOM.paletteScaleBtns.forEach(b => {
        b.classList.toggle('active', parseFloat(b.dataset.scale) === scale);
      });
    }
    updatePaletteView();
  }

  function selectAllPieces() {
    DOM.paletteGrid.querySelectorAll('.palette-piece').forEach(p => p.classList.add('selected'));
    showToast('全ピースを選択しました');
  }

  function deselectPieces() {
    state.selectedPieceId = null;
    DOM.paletteGrid.querySelectorAll('.palette-piece').forEach(p => p.classList.remove('selected'));
  }

  // =========================================================================
  // 6. キャンバス配置＆インタラクション
  // =========================================================================
  function getCellCoordFromEvent(e) {
    const rect = DOM.gridOverlay.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const scaleX = DOM.mainCanvas.width / rect.width;
    const scaleY = DOM.mainCanvas.height / rect.height;

    const canvasX = clientX * scaleX;
    const canvasY = clientY * scaleY;

    const col = Math.floor(canvasX / state.tileWidth);
    const row = Math.floor(canvasY / state.tileHeight);

    if (col >= 0 && col < state.canvasCols && row >= 0 && row < state.canvasRows) {
      return { col, row };
    }
    return null;
  }

  function handleCanvasClick(e) {
    if (state.eyedropperActive) {
      pickColorFromCanvas(e);
      return;
    }

    const cell = getCellCoordFromEvent(e);
    if (!cell) return;

    const key = `${cell.col}_${cell.row}`;

    // パレットでピースが選択されている場合はスタンプ配置
    if (state.selectedPieceId) {
      pushHistory();
      state.gridMap.set(key, {
        pieceId: state.selectedPieceId,
        rotation: 0,
        flipH: false,
        flipV: false
      });
      state.selectedCell = cell;
      renderAll();
    } else {
      // 既存セルの選択
      if (state.gridMap.has(key)) {
        state.selectedCell = cell;
        highlightSelectedCell(cell);
      } else {
        state.selectedCell = null;
        removeHighlight();
      }
    }
  }

  function handleCanvasDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  }

  function handleCanvasDrop(e) {
    e.preventDefault();
    e.stopPropagation(); // window.dropへのバブリングを確実に遮断！
    state.isDraggingInternalPiece = false;

    const cell = getCellCoordFromEvent(e);
    if (!cell) return;

    const pieceId = e.dataTransfer.getData('application/x-piece-id') || e.dataTransfer.getData('text/plain');
    if (pieceId) {
      pushHistory();
      const key = `${cell.col}_${cell.row}`;
      state.gridMap.set(key, {
        pieceId: pieceId,
        rotation: 0,
        flipH: false,
        flipV: false
      });
      state.selectedCell = cell;
      renderAll();
      showToast(`タイルを (${cell.col}, ${cell.row}) に配置しました`);
    }
  }

  function highlightSelectedCell(cell) {
    removeHighlight();
    const el = document.createElement('div');
    el.className = 'grid-cell-highlight';
    el.id = 'cell-highlight-box';
    el.style.left = `${cell.col * state.tileWidth}px`;
    el.style.top = `${cell.row * state.tileHeight}px`;
    el.style.width = `${state.tileWidth}px`;
    el.style.height = `${state.tileHeight}px`;
    DOM.gridOverlay.appendChild(el);
  }

  function removeHighlight() {
    const el = document.getElementById('cell-highlight-box');
    if (el) el.remove();
  }

  // 変形操作
  function rotateSelectedCell() {
    if (!state.selectedCell) return;
    const key = `${state.selectedCell.col}_${state.selectedCell.row}`;
    const data = state.gridMap.get(key);
    if (data) {
      pushHistory();
      data.rotation = (data.rotation + 90) % 360;
      renderAll();
    }
  }

  function flipHSelectedCell() {
    if (!state.selectedCell) return;
    const key = `${state.selectedCell.col}_${state.selectedCell.row}`;
    const data = state.gridMap.get(key);
    if (data) {
      pushHistory();
      data.flipH = !data.flipH;
      renderAll();
    }
  }

  function flipVSelectedCell() {
    if (!state.selectedCell) return;
    const key = `${state.selectedCell.col}_${state.selectedCell.row}`;
    const data = state.gridMap.get(key);
    if (data) {
      pushHistory();
      data.flipV = !data.flipV;
      renderAll();
    }
  }

  function removeSelectedCell() {
    if (!state.selectedCell) return;
    const key = `${state.selectedCell.col}_${state.selectedCell.row}`;
    if (state.gridMap.has(key)) {
      pushHistory();
      state.gridMap.delete(key);
      state.selectedCell = null;
      removeHighlight();
      renderAll();
      showToast('タイルを削除しました');
    }
  }

  function clearCanvas() {
    if (state.gridMap.size === 0) {
      showToast('キャンバスにはまだタイルが配置されていません', 'ℹ️');
      return;
    }
    pushHistory();
    state.gridMap.clear();
    state.selectedCell = null;
    removeHighlight();
    renderAll();
    showToast('キャンバスの配置をクリアしました（Ctrl+Zで元に戻せます）', '🗑️');
  }

  // =========================================================================
  // 7. 新機能 ①: タイルの自動整列機能 (Auto-Grid Smart Alignment)
  // =========================================================================
  function autoAlignPieces(columns) {
    if (state.pieces.length === 0) {
      showToast('配置するピースがありません。先に画像を読み込んでください', '⚠️');
      return;
    }

    pushHistory();
    state.gridMap.clear();

    const cols = Math.max(1, columns);
    const rows = Math.ceil(state.pieces.length / cols);

    // キャンバスサイズを整列結果にピッタリ自動調整（余計な空白を完全排除！）
    state.canvasCols = cols;
    state.canvasRows = rows;
    updateCanvasDimensions();

    state.pieces.forEach((piece, index) => {
      const c = index % cols;
      const r = Math.floor(index / cols);
      state.gridMap.set(`${c}_${r}`, {
        pieceId: piece.id,
        rotation: 0,
        flipH: false,
        flipV: false
      });
    });

    renderAll();
    showToast(`${state.pieces.length} ピースを ${cols} 列で自動整列しました！`, '⚡');
  }

  function autoAlignSquare() {
    if (state.pieces.length === 0) {
      showToast('配置するピースがありません', '⚠️');
      return;
    }
    // 最も正方形に近い列数を算出 (オートタイルの2列ブロック崩れを防ぐため偶数優先)
    let squareCols = Math.ceil(Math.sqrt(state.pieces.length));
    if (squareCols > 2 && squareCols % 2 !== 0 && state.pieces.length % 2 === 0) {
      squareCols++;
    }
    if (DOM.inputAlignCols) DOM.inputAlignCols.value = squareCols;
    autoAlignPieces(squareCols);
  }

  function autoAlignOriginal() {
    if (state.pieces.length === 0) {
      showToast('配置するピースがありません。先に画像を読み込んでください', '⚠️');
      return;
    }
    pushHistory();
    state.gridMap.clear();

    const cols = state.sourceCols || 16;
    const rows = Math.ceil(state.pieces.length / cols);
    state.canvasCols = cols;
    state.canvasRows = rows;
    if (DOM.inputAlignCols) DOM.inputAlignCols.value = cols;
    updateCanvasDimensions();

    state.pieces.forEach((piece, index) => {
      const c = (piece.col !== undefined) ? piece.col : (index % cols);
      const r = (piece.row !== undefined) ? piece.row : Math.floor(index / cols);
      state.gridMap.set(`${c}_${r}`, {
        pieceId: piece.id,
        rotation: 0,
        flipH: false,
        flipV: false
      });
    });

    renderAll();
    showToast(`元画像の配置通りにキャンバスへ完全展開しました！（${cols}x${rows} タイル）`, '🗺️');
  }

  // =========================================================================
  // 8. 新機能 ②: 透明色の一括抜き (Chroma Key & Magic Wand)
  // =========================================================================
  function toggleEyedropper() {
    if (window.EyeDropper) {
      const eyeDropper = new EyeDropper();
      eyeDropper.open().then(result => {
        updateChromaColor(result.sRGBHex);
        showToast(`色を取得しました: ${result.sRGBHex}`, '🧪');
      }).catch(() => {});
    } else {
      state.eyedropperActive = !state.eyedropperActive;
      if (state.eyedropperActive) {
        DOM.btnEyedropper.classList.add('primary-glow');
        showToast('キャンバス上をクリックして透明化したい色を抽出してください', '🧪');
      } else {
        DOM.btnEyedropper.classList.remove('primary-glow');
      }
    }
  }

  function pickColorFromCanvas(e) {
    const rect = DOM.gridOverlay.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) * (DOM.mainCanvas.width / rect.width));
    const y = Math.floor((e.clientY - rect.top) * (DOM.mainCanvas.height / rect.height));

    const p = mainCtx.getImageData(x, y, 1, 1).data;
    const hex = rgbToHex(p[0], p[1], p[2]);
    updateChromaColor(hex);

    state.eyedropperActive = false;
    DOM.btnEyedropper.classList.remove('primary-glow');
    showToast(`色を抽出しました: ${hex}`, '🧪');
  }

  function updateChromaColor(hex) {
    DOM.colorPicker.value = hex;
    DOM.colorHexText.textContent = hex.toUpperCase();
    const rgb = hexToRgb(hex);
    if (rgb) state.chromaColor = rgb;
  }

  function applyTransparencyToAll() {
    if (state.pieces.length === 0) {
      showToast('透明化を適用するピースがありません', '⚠️');
      return;
    }

    pushHistory();
    const target = state.chromaColor;
    const tolSq = Math.pow((state.chromaTolerance / 100) * 441.67, 2); // ユークリッド距離の2乗

    let modifiedCount = 0;

    state.pieces.forEach(piece => {
      const pCtx = piece.canvas.getContext('2d');
      const imgData = pCtx.getImageData(0, 0, piece.canvas.width, piece.canvas.height);
      const data = imgData.data;

      for (let i = 0; i < data.length; i += 4) {
        // すでに透明ならスキップ
        if (data[i + 3] === 0) continue;

        const dr = data[i] - target.r;
        const dg = data[i + 1] - target.g;
        const db = data[i + 2] - target.b;
        const distSq = dr * dr + dg * dg + db * db;

        if (distSq <= tolSq) {
          data[i + 3] = 0; // 完全透明化
        }
      }

      pCtx.putImageData(imgData, 0, 0);
      modifiedCount++;
    });

    updatePaletteView();
    renderAll();
    showToast(`全 ${modifiedCount} ピースの透明色一括抜きを完了しました！`, '🪄');
  }

  // =========================================================================
  // 9. 描画レンダリングエンジン
  // =========================================================================
  function renderAll() {
    mainCtx.imageSmoothingEnabled = false;
    mainCtx.clearRect(0, 0, DOM.mainCanvas.width, DOM.mainCanvas.height);

    const pieceMap = new Map();
    state.pieces.forEach(p => pieceMap.set(p.id, p));

    state.gridMap.forEach((val, key) => {
      const [col, row] = key.split('_').map(Number);
      const piece = pieceMap.get(val.pieceId);
      if (!piece) return;

      const destX = col * state.tileWidth;
      const destY = row * state.tileHeight;

      mainCtx.save();
      mainCtx.translate(destX + state.tileWidth / 2, destY + state.tileHeight / 2);

      if (val.rotation !== 0) {
        mainCtx.rotate((val.rotation * Math.PI) / 180);
      }
      if (val.flipH || val.flipV) {
        mainCtx.scale(val.flipH ? -1 : 1, val.flipV ? -1 : 1);
      }

      mainCtx.drawImage(
        piece.canvas,
        -state.tileWidth / 2,
        -state.tileHeight / 2,
        state.tileWidth,
        state.tileHeight
      );

      mainCtx.restore();
    });

    if (state.selectedCell) {
      highlightSelectedCell(state.selectedCell);
    }
  }

  // =========================================================================
  // 10. 新機能 ③: 現代画像フォーマット対応エクスポート (PNG32 / WebP / SVG / ZIP)
  // =========================================================================
  function openExportModal() {
    if (state.gridMap.size === 0) {
      showToast('エクスポートする画像が配置されていません', '⚠️');
      return;
    }

    // プレビュー生成
    DOM.previewCanvas.width = DOM.mainCanvas.width;
    DOM.previewCanvas.height = DOM.mainCanvas.height;
    previewCtx.clearRect(0, 0, DOM.previewCanvas.width, DOM.previewCanvas.height);
    if (state.canvasBgColor && state.canvasBgColor !== 'transparent') {
      previewCtx.fillStyle = state.canvasBgColor;
      previewCtx.fillRect(0, 0, DOM.previewCanvas.width, DOM.previewCanvas.height);
    }
    previewCtx.drawImage(DOM.mainCanvas, 0, 0);

    DOM.exportInfoText.textContent = `サイズ: ${DOM.mainCanvas.width} x ${DOM.mainCanvas.height} px (${state.gridMap.size} タイル配置済)`;
    DOM.modalExport.classList.remove('hidden');
  }

  function closeExportModal() {
    DOM.modalExport.classList.add('hidden');
  }

  async function executeExportImage() {
    const fmtRadio = Array.from(DOM.exportFmtRadios).find(r => r.checked);
    const fmt = fmtRadio ? fmtRadio.value : 'png';
    const filename = (DOM.exportFilename.value.trim() || 'ChouGazo_Combined');

    if (fmt === 'svg') {
      await exportAsSVG(filename);
      closeExportModal();
      return;
    }

    let mimeType = 'image/png';
    let ext = '.png';
    let quality = undefined;

    if (fmt === 'webp') {
      mimeType = 'image/webp';
      ext = '.webp';
      quality = parseInt(DOM.webpSlider.value, 10) / 100;
    }

    const defaultName = `${filename}${ext}`;

    // 背景色が設定されている場合は合成用Canvasを生成
    let targetCanvas = DOM.mainCanvas;
    if (state.canvasBgColor && state.canvasBgColor !== 'transparent') {
      targetCanvas = document.createElement('canvas');
      targetCanvas.width = DOM.mainCanvas.width;
      targetCanvas.height = DOM.mainCanvas.height;
      const tCtx = targetCanvas.getContext('2d');
      tCtx.fillStyle = state.canvasBgColor;
      tCtx.fillRect(0, 0, targetCanvas.width, targetCanvas.height);
      tCtx.drawImage(DOM.mainCanvas, 0, 0);
    }

    // File System Access API (名前を付けて保存ダイアログ)
    if ('showSaveFilePicker' in window) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: defaultName,
          types: [{
            description: fmt === 'webp' ? 'WebP 画像 (*.webp)' : 'PNG 画像 (*.png)',
            accept: { [mimeType]: [ext] }
          }]
        });
        const blob = await new Promise(resolve => targetCanvas.toBlob(resolve, mimeType, quality));
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        closeExportModal();
        showToast(`${handle.name} を保存しました！`, '💾');
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
        console.warn('showSaveFilePicker fallback:', err);
      }
    }

    // 通常ダウンロードへのフォールバック
    const dataUrl = targetCanvas.toDataURL(mimeType, quality);
    const link = document.createElement('a');
    link.download = defaultName;
    link.href = dataUrl;
    link.click();

    closeExportModal();
    showToast(`${defaultName} をダウンロードしました！`, '💾');
  }

  async function exportAsSVG(filename) {
    const w = DOM.mainCanvas.width;
    const h = DOM.mainCanvas.height;
    const pngDataUrl = DOM.mainCanvas.toDataURL('image/png');

    const svgContent = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
  <image width="${w}" height="${h}" xlink:href="${pngDataUrl}" />
</svg>`;

    const defaultName = `${filename}.svg`;

    if ('showSaveFilePicker' in window) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: defaultName,
          types: [{
            description: 'SVG ベクター画像 (*.svg)',
            accept: { 'image/svg+xml': ['.svg'] }
          }]
        });
        const writable = await handle.createWritable();
        await writable.write(svgContent);
        await writable.close();
        showToast(`${handle.name} を保存しました！`, '💾');
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
        console.warn('showSaveFilePicker fallback:', err);
      }
    }

    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = defaultName;
    link.href = url;
    link.click();
    URL.revokeObjectURL(url);

    showToast(`${defaultName} をダウンロードしました！`, '💾');
  }

  async function executeExportZip() {
    if (!window.JSZip) {
      showToast('ZIPライブラリが読み込まれていません', '⚠️');
      return;
    }

    showToast('個別タイルのZIPアーカイブを生成中...', '📦');
    const zip = new JSZip();
    const filename = (DOM.exportFilename.value.trim() || 'ChouGazo_Tiles');
    const pieceMap = new Map();
    state.pieces.forEach(p => pieceMap.set(p.id, p));

    let count = 0;
    state.gridMap.forEach((val, key) => {
      const [col, row] = key.split('_').map(Number);
      const piece = pieceMap.get(val.pieceId);
      if (!piece) return;

      const offCanvas = document.createElement('canvas');
      offCanvas.width = state.tileWidth;
      offCanvas.height = state.tileHeight;
      const offCtx = offCanvas.getContext('2d');

      offCtx.save();
      offCtx.translate(state.tileWidth / 2, state.tileHeight / 2);
      if (val.rotation !== 0) offCtx.rotate((val.rotation * Math.PI) / 180);
      if (val.flipH || val.flipV) offCtx.scale(val.flipH ? -1 : 1, val.flipV ? -1 : 1);
      offCtx.drawImage(piece.canvas, -state.tileWidth / 2, -state.tileHeight / 2);
      offCtx.restore();

      const base64 = offCanvas.toDataURL('image/png').split(',')[1];
      zip.file(`tile_x${col}_y${row}.png`, base64, { base64: true });
      count++;
    });

    const contentBlob = await zip.generateAsync({ type: 'blob' });
    const defaultName = `${filename}_tiles.zip`;

    if ('showSaveFilePicker' in window) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: defaultName,
          types: [{
            description: 'ZIP アーカイブ (*.zip)',
            accept: { 'application/zip': ['.zip'] }
          }]
        });
        const writable = await handle.createWritable();
        await writable.write(contentBlob);
        await writable.close();
        closeExportModal();
        showToast(`${count} 個のタイルを保存しました！`, '📦');
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
        console.warn('showSaveFilePicker fallback:', err);
      }
    }

    const url = URL.createObjectURL(contentBlob);
    const link = document.createElement('a');
    link.download = defaultName;
    link.href = url;
    link.click();
    URL.revokeObjectURL(url);
    closeExportModal();
    showToast(`${count} 個のタイルをZIP保存しました！`, '📦');
  }

  // =========================================================================
  // 11. 履歴管理 (Undo / Redo)
  // =========================================================================
  function pushHistory() {
    const snapshot = {
      gridMap: new Map(state.gridMap),
      cols: state.canvasCols,
      rows: state.canvasRows
    };
    state.undoStack.push(snapshot);
    if (state.undoStack.length > state.maxHistory) {
      state.undoStack.shift();
    }
    state.redoStack = [];
    updateUndoRedoUI();
  }

  function undo() {
    if (state.undoStack.length === 0) return;
    const current = {
      gridMap: new Map(state.gridMap),
      cols: state.canvasCols,
      rows: state.canvasRows
    };
    state.redoStack.push(current);

    const prev = state.undoStack.pop();
    state.gridMap = new Map(prev.gridMap);
    state.canvasCols = prev.cols;
    state.canvasRows = prev.rows;
    state.selectedCell = null;
    removeHighlight();
    updateCanvasDimensions();
    renderAll();
    updateUndoRedoUI();
    showToast('元に戻しました (Undo)');
  }

  function redo() {
    if (state.redoStack.length === 0) return;
    const current = {
      gridMap: new Map(state.gridMap),
      cols: state.canvasCols,
      rows: state.canvasRows
    };
    state.undoStack.push(current);

    const next = state.redoStack.pop();
    state.gridMap = new Map(next.gridMap);
    state.canvasCols = next.cols;
    state.canvasRows = next.rows;
    state.selectedCell = null;
    removeHighlight();
    updateCanvasDimensions();
    renderAll();
    updateUndoRedoUI();
    showToast('やり直しました (Redo)');
  }

  function updateUndoRedoUI() {
    DOM.btnUndo.disabled = state.undoStack.length === 0;
    DOM.btnRedo.disabled = state.redoStack.length === 0;
  }

  function handleKeyShortcuts(e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveProject();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'o') {
      e.preventDefault();
      DOM.fileInputProject.click();
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
      e.preventDefault();
      if (e.shiftKey) redo();
      else undo();
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
      e.preventDefault();
      redo();
    } else if (e.key === 'Delete' || e.key === 'Backspace') {
      if (state.selectedCell && document.activeElement.tagName !== 'INPUT') {
        e.preventDefault();
        removeSelectedCell();
      }
    }
  }

  // =========================================================================
  // 12. プロジェクト保存 ＆ 互換復元エンジン (*.tilemap / JSON / XML)
  // =========================================================================
  async function saveProject() {
    // ピースのCanvasデータをDataURL化
    const serializedPieces = state.pieces.map(p => ({
      id: p.id,
      name: p.name,
      dataUrl: p.canvas.toDataURL('image/png')
    }));

    // グリッド上の配置データをシリアライズ
    const serializedGrid = [];
    state.gridMap.forEach((val, key) => {
      serializedGrid.push({
        key, // "col_row"
        pieceId: val.pieceId,
        rotation: val.rotation || 0,
        flipH: !!val.flipH,
        flipV: !!val.flipV
      });
    });

    const projectData = {
      app: "ChouGazoTamashiiCombine",
      formatVersion: "2.1",
      timestamp: new Date().toISOString(),
      gridSetting: {
        chipX: state.tileWidth,
        chipY: state.tileHeight,
        tileX: state.canvasCols,
        tileY: state.canvasRows,
        dpi: 96,
        backgroundColor: state.chromaColor
      },
      pieces: serializedPieces,
      placedTiles: serializedGrid,
      sourceCols: state.sourceCols,
      canvasBgColor: state.canvasBgColor || 'transparent'
    };

    const jsonString = JSON.stringify(projectData, null, 2);
    const now = new Date();
    const dateStr = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
    const defaultName = `project_${dateStr}.tilemap`;

    // 1. ブラウザ標準のネイティブ保存ダイアログ (Edge / Chrome 推奨)
    if ('showSaveFilePicker' in window) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: defaultName,
          types: [{
            description: 'タイルマッププロジェクト (*.tilemap)',
            accept: { 'application/json': ['.tilemap', '.json'] }
          }]
        });
        const writable = await handle.createWritable();
        await writable.write(jsonString);
        await writable.close();
        showToast(`${handle.name} を保存しました！`, '💾');
        saveIniSettings();
        return;
      } catch (err) {
        if (err.name === 'AbortError') {
          showToast('プロジェクト保存をキャンセルしました', 'ℹ️');
          return;
        }
        console.warn('showSaveFilePicker fallback:', err);
      }
    }

    // 2. サーバーAPI稼働時: フォルダへ直接バックアップ保存
    try {
      const res = await fetch('/api/save_project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: defaultName,
          content: jsonString,
          dir: state.lastFolderPath || state.baseDir
        })
      });
      if (res.ok) {
        const ret = await res.json();
        showToast(`プロジェクトを保存しました！ (${defaultName})`, '💾');
        saveIniSettings();
        return;
      }
    } catch (e) {
      // フォールバックへ
    }

    // 3. 最終フォールバック: 通常のブラウザダウンロード
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.download = defaultName;
    a.href = url;
    a.click();
    URL.revokeObjectURL(url);

    showToast('プロジェクトを保存しました (*.tilemap)', '💾');
  }

  async function handleOpenProjectClick() {
    try {
      const res = await fetch('/api/dialog/open_project', { method: 'POST' });
      if (res.ok) {
        const ret = await res.json();
        if (ret.canceled) return;
        if (ret.content) {
          parseAndLoadProject(ret.content, ret.filename);
          return;
        }
      }
    } catch (e) {
      // サーバー未稼働時はブラウザ標準のダイアログへフォールバック
    }
    DOM.fileInputProject.click();
  }

  function handleProjectFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
      loadProjectFile(file);
    }
    e.target.value = '';
  }

  function loadProjectFile(file) {
    showToast(`${file.name} を読み込み中...`, '⏳');
    const reader = new FileReader();
    reader.onload = (e) => {
      parseAndLoadProject(e.target.result, file.name);
    };
    reader.readAsText(file);
  }

  function parseAndLoadProject(content, fileName) {
    // XML判定 (デスクトップ版の *.tilemap)
    if (content.trim().startsWith('<') || content.includes('xmlns:') || content.includes('<GridSetting>')) {
      loadLegacyXmlTilemap(content, fileName);
    } else {
      // JSON判定 (Web版 *.tilemap / *.json)
      try {
        const json = JSON.parse(content);
        loadModernJsonProject(json, fileName);
      } catch (err) {
        console.error("Project parse error:", err);
        showToast('プロジェクトの解析に失敗しました。ファイル形式を確認してください。', '⚠️');
      }
    }
  }

  function loadModernJsonProject(json, fileName) {
    pushHistory();
    // 設定復元
    if (json.gridSetting) {
      state.tileWidth = json.gridSetting.chipX || json.tileWidth || 32;
      state.tileHeight = json.gridSetting.chipY || json.tileHeight || 32;
      state.canvasCols = json.gridSetting.tileX || json.canvasCols || 16;
      state.canvasRows = json.gridSetting.tileY || json.canvasRows || 16;
    } else {
      state.tileWidth = json.tileWidth || 32;
      state.tileHeight = json.tileHeight || 32;
      state.canvasCols = json.canvasCols || 16;
      state.canvasRows = json.canvasRows || 16;
    }

    state.sourceCols = json.sourceCols || 16;

    DOM.inputCustomW.value = state.tileWidth;
    DOM.inputCustomH.value = state.tileHeight;
    DOM.sizeChips.forEach(c => {
      c.classList.toggle('active', parseInt(c.dataset.size, 10) === state.tileWidth && state.tileWidth === state.tileHeight);
    });

    updateCanvasDimensions();

    // ピースの読み込み
    const piecesData = json.pieces || [];
    state.pieces = [];
    state.gridMap.clear();

    if (piecesData.length === 0) {
      updatePaletteView();
      renderAll();
      showToast(`プロジェクト設定を復元しました (${fileName})`, '📂');
      return;
    }

    let loadedCount = 0;
    piecesData.forEach((pData) => {
      const img = new Image();
      img.onload = () => {
        const pCanvas = document.createElement('canvas');
        pCanvas.width = state.tileWidth;
        pCanvas.height = state.tileHeight;
        const pCtx = pCanvas.getContext('2d');
        pCtx.drawImage(img, 0, 0, state.tileWidth, state.tileHeight);

        state.pieces.push({
          id: pData.id || `piece_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          name: pData.name || `piece_${loadedCount}`,
          canvas: pCanvas
        });

        loadedCount++;
        if (loadedCount === piecesData.length) {
          // グリッド配置復元
          if (Array.isArray(json.placedTiles)) {
            json.placedTiles.forEach(t => {
              state.gridMap.set(t.key, {
                pieceId: t.pieceId,
                rotation: t.rotation || 0,
                flipH: !!t.flipH,
                flipV: !!t.flipV
              });
            });
          }
          updatePaletteView();
          renderAll();
          showToast(`プロジェクトを完全復元しました！（${state.pieces.length} ピース）`, '🎉');
        }
      };
      img.src = pData.dataUrl;
    });
  }

  function loadLegacyXmlTilemap(xmlText, fileName) {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(xmlText, 'text/xml');

      // GridSetting の解析
      let chipX = 32, chipY = 32, tileX = 16, tileY = 16;
      const chipXNode = doc.querySelector('ChipX') || doc.querySelector('cellW');
      const chipYNode = doc.querySelector('ChipY') || doc.querySelector('cellH');
      const tileXNode = doc.querySelector('TileX') || doc.querySelector('MaxCellX');
      const tileYNode = doc.querySelector('TileY') || doc.querySelector('MaxCellY');

      if (chipXNode) chipX = parseInt(chipXNode.textContent, 10) || 32;
      if (chipYNode) chipY = parseInt(chipYNode.textContent, 10) || 32;
      if (tileXNode) tileX = parseInt(tileXNode.textContent, 10) || 16;
      if (tileYNode) tileY = parseInt(tileYNode.textContent, 10) || 16;

      pushHistory();
      state.tileWidth = chipX;
      state.tileHeight = chipY;
      state.canvasCols = tileX;
      state.canvasRows = tileY;

      DOM.inputCustomW.value = chipX;
      DOM.inputCustomH.value = chipY;
      DOM.sizeChips.forEach(c => {
        c.classList.toggle('active', parseInt(c.dataset.size, 10) === chipX && chipX === chipY);
      });

      updateCanvasDimensions();
      renderAll();

      showToast(`デスクトップ版 *.tilemap を解析しました！(${chipX}x${chipY}px, ${tileX}x${tileY}マス) 画像をD&Dして作業を継続できます`, '🏛️');
    } catch (err) {
      console.error("XML parse error:", err);
      showToast('デスクトップ版 *.tilemap の解析に失敗しました。', '⚠️');
    }
  }

  // =========================================================================
  // 12. ユーティリティ関数
  // =========================================================================
  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
  }

  function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  function showToast(message, icon = '✨') {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
    DOM.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // 起動
  window.addEventListener('DOMContentLoaded', init);
})();
